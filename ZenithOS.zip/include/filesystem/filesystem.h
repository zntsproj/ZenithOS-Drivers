#ifndef INCLUDE_FILESYSTEM_H_
#define INCLUDE_FILESYSTEM_H_

#include <stdbool.h>

// Function to delete a file or directory
bool fs_delete(const char *path);

// Function to create a file or directory
bool fs_add(const char *path);

// Function to rename a file or directory
bool fs_rename(const char *old_path, const char *new_path);

#endif // INCLUDE_FILESYSTEM_H_