// net/scan.h
#ifndef NET_SCAN_H_
#define NET_SCAN_H_

#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>

// Structure to store information about a discovered device
typedef struct {

    char ip_address[INET6_ADDRSTRLEN];  // Use INET6_ADDRSTRLEN to support IPv6
    char hostname[NI_MAXHOST];

} DeviceInfo;

// Function to scan the local network for devices
int net_scan(DeviceInfo **devices, int *num_devices);

#endif // NET_SCAN_H_