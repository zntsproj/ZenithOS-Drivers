#ifndef HTTP_H
#define HTTP_H

#include <curl/curl.h>
#include <string.h>
#include <stdio.h>

// Структура для хранения ответа
struct http_response {
    char* data;
    size_t size;
};

// Функция для выполнения HTTP-запроса
CURLcode http_request(const char* url, const char* method, const char* data, struct http_response* response);

// Вспомогательные функции для разных типов запросов
CURLcode http_get(const char* url, struct http_response* response);
CURLcode http_post(const char* url, const char* data, struct http_response* response);

#endif