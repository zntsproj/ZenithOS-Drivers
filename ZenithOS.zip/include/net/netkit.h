// net/netkit.h
#ifndef INCLUDE_NET_NETKIT_H_
#define INCLUDE_NET_NETKIT_H_

#include <asm/types.h>
#include <linux/netlink.h>
#include <linux/rtnetlink.h>
#include <sys/socket.h>
#include <unistd.h>

/**
 * @struct netkit_socket_t
 * @brief Structure to hold netlink socket information.
 */
typedef struct {
  int sock_fd; /**< Netlink socket file descriptor. */
  struct sockaddr_nl src_addr; /**< Source address. */
  struct sockaddr_nl dest_addr; /**< Destination address. */
  struct nlmsghdr *nlh; /**< Pointer to netlink message header. */
  struct iovec iov; /**< I/O vector for sendmsg/recvmsg. */
  struct msghdr msg; /**< Message header for sendmsg/recvmsg. */
  char buf[4096]; /**< Buffer for sending/receiving data. */
} netkit_socket_t;

/**
 * @brief Creates a netlink socket.
 *
 * @param sock Pointer to a netkit_socket_t structure.
 * @param protocol Netlink protocol (e.g., NETLINK_ROUTE).
 * @return 0 on success, -1 on error.
 */
int nl_socket(netkit_socket_t *sock, int protocol) {
  // Create the socket.
  sock->sock_fd = socket(PF_NETLINK, SOCK_RAW, protocol);
  if (sock->sock_fd < 0) {
    return -1;
  }

  // Fill in the source address.
  memset(&sock->src_addr, 0, sizeof(sock->src_addr));
  sock->src_addr.nl_family = AF_NETLINK;
  sock->src_addr.nl_pid = getpid();

  // Bind the socket to the source address.
  if (bind(sock->sock_fd, (struct sockaddr *)&sock->src_addr,
           sizeof(sock->src_addr)) < 0) {
    close(sock->sock_fd);
    return -1;
  }

  // Initialize destination address (family and pid are usually enough).
  memset(&sock->dest_addr, 0, sizeof(sock->dest_addr));
  sock->dest_addr.nl_family = AF_NETLINK;

  return 0;
}

/**
 * @brief Sends a netlink message.
 *
 * @param sock Pointer to the netkit_socket_t structure.
 * @param port Destination port ID.
 * @param type Message type.
 * @param data Pointer to the message data.
 * @param data_len Length of the message data.
 * @return The number of bytes sent on success, -1 on error.
 */
int nl_send(netkit_socket_t *sock, __u32 port, int type, void *data, int data_len) {
    sock->dest_addr.nl_pid = port;  // Set destination port ID
    sock->nlh = (struct nlmsghdr *)sock->buf;
    memset(sock->nlh, 0, NLMSG_HDRLEN);
    sock->nlh->nlmsg_len = NLMSG_HDRLEN + data_len;
    sock->nlh->nlmsg_pid = sock->src_addr.nl_pid;  // Use current process's PID
    sock->nlh->nlmsg_flags = 0;  // No flags set by default
    sock->nlh->nlmsg_type = type;

    memcpy(NLMSG_DATA(sock->nlh), data, data_len); // Copy data to message payload

    sock->iov.iov_base = (void *)sock->nlh;  // Set pointer to message header
    sock->iov.iov_len = sock->nlh->nlmsg_len;  // Set message length

    sock->msg.msg_name = (void *)&sock->dest_addr;  // Set destination address
    sock->msg.msg_namelen = sizeof(sock->dest_addr);  // Set destination address length
    sock->msg.msg_iov = &sock->iov;  // Set pointer to I/O vector
    sock->msg.msg_iovlen = 1;  // Number of I/O vectors

    return sendmsg(sock->sock_fd, &sock->msg, 0);  // Send the message using sendmsg()
}

/**
 * @brief Receives a netlink message.
 *
 * @param sock Pointer to the netkit_socket_t structure.
 * @return The number of bytes received on success, -1 on error.
 */
int nl_receive(netkit_socket_t *sock) {
    memset(sock->buf, 0, sizeof(sock->buf));   // Clear the buffer before receiving
    sock->iov.iov_base = (void *)sock->buf;   // Set pointer to the buffer
    sock->iov.iov_len = sizeof(sock->buf);   // Set buffer length

    sock->msg.msg_name = (void *)&(sock->dest_addr);  // Set pointer to destination address (to receive address information)
    sock->msg.msg_namelen = sizeof(sock->dest_addr);  // Set destination address length
    sock->msg.msg_iov = &sock->iov;  // Set pointer to I/O vector
    sock->msg.msg_iovlen = 1;  // Number of I/O vectors

    return recvmsg(sock->sock_fd, &sock->msg, 0);  // Receive the message using recvmsg()
}

/**
 * @brief Closes the netlink socket.
 *
 * @param sock Pointer to the netkit_socket_t structure.
 * @return 0 on success, -1 on error.
 */
int nl_close(netkit_socket_t *sock) {
    return close(sock->sock_fd);
}

#endif  // INCLUDE_NET_NETKIT_H_