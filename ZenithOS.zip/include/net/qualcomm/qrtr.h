/**
 * @file qrtr.h
 * @brief This header file defines the API for working with QRTR sockets.
 *
 * QRTR (Qualcomm Radio Transport) is a protocol used for communication
 * with Qualcomm modems. This API provides a set of functions for creating,
 * configuring, and using QRTR sockets in applications.
 */

#ifndef _ZENITH_QRTR_H
#define _ZENITH_QRTR_H

#include <linux/qrtr.h>
#include <stdint.h>
#include <sys/socket.h>

/**
 * @brief Type for QRTR socket descriptor.
 */
typedef int qrtr_socket_t;

/**
 * @brief Structure for QRTR address.
 *
 * @param node_id The destination node ID.
 * @param port_id The destination port ID.
 */
typedef struct qrtr_address {
    uint32_t node_id;
    uint32_t port_id;
} qrtr_address_t;

/**
 * @brief Creates a QRTR socket.
 *
 * @param domain The protocol family (AF_QIPC).
 * @param type The socket type (SOCK_DGRAM or SOCK_STREAM).
 * @param protocol The protocol (QRTR_PROTO_CTRL or QRTR_PROTO_DATA).
 *
 * @return On success, returns a socket descriptor. On error, returns -1.
 */
qrtr_socket_t qrtr_socket(int domain, int type, int protocol);

/**
 * @brief Binds a socket to a local address.
 *
 * @param sockfd The socket descriptor.
 * @param addr A pointer to the qrtr_address structure containing the local address.
 * @param addrlen The size of the qrtr_address structure.
 *
 * @return On success, returns 0. On error, returns -1.
 */
int qrtr_bind(qrtr_socket_t sockfd, const qrtr_address_t *addr, socklen_t addrlen);

/**
 * @brief Establishes a connection to a remote QRTR address.
 *
 * @param sockfd The socket descriptor.
 * @param addr A pointer to the qrtr_address structure containing the remote address.
 * @param addrlen The size of the qrtr_address structure.
 *
 * @return On success, returns 0. On error, returns -1.
 */
int qrtr_connect(qrtr_socket_t sockfd, const qrtr_address_t *addr, socklen_t addrlen);

/**
 * @brief Listens for incoming connections on a socket.
 *
 * @param sockfd The socket descriptor.
 * @param backlog The maximum number of pending connections.
 *
 * @return On success, returns 0. On error, returns -1.
 */
int qrtr_listen(qrtr_socket_t sockfd, int backlog);

/**
 * @brief Accepts a connection on a socket.
 *
 * @param sockfd The socket descriptor.
 * @param addr A pointer to a qrtr_address structure to store the client address.
 * @param addrlen A pointer to the size of the qrtr_address structure.
 *
 * @return On success, returns a new socket descriptor for the accepted connection. On error, returns -1.
 */
qrtr_socket_t qrtr_accept(qrtr_socket_t sockfd, qrtr_address_t *addr, socklen_t *addrlen);

/**
 * @brief Sends data over a QRTR socket.
 *
 * @param sockfd The socket descriptor.
 * @param buf A pointer to the buffer containing the data to send.
 * @param len The size of the buffer.
 * @param flags Flags for the send operation (0 or MSG_DONTWAIT).
 *
 * @return On success, returns the number of bytes sent. On error, returns -1.
 */
ssize_t qrtr_send(qrtr_socket_t sockfd, const void *buf, size_t len, int flags);

/**
 * @brief Receives data from a QRTR socket.
 *
 * @param sockfd The socket descriptor.
 * @param buf A pointer to the buffer to store the received data.
 * @param len The size of the buffer.
 * @param flags Flags for the receive operation (0 or MSG_DONTWAIT).
 *
 * @return On success, returns the number of bytes received. On error, returns -1.
 */
ssize_t qrtr_recv(qrtr_socket_t sockfd, void *buf, size_t len, int flags);

/**
 * @brief Closes a QRTR socket.
 *
 * @param sockfd The socket descriptor.
 *
 * @return On success, returns 0. On error, returns -1.
 */
int qrtr_close(qrtr_socket_t sockfd);

#endif