/**
 * @file cmp/assembly.h
 * @brief Header file for assembling CMP projects into .zapp files.
 */
#ifndef CMP_ASSEMBLY_H
#define CMP_ASSEMBLY_H

#include <stdio.h>  // For error reporting (e.g., fprintf)

//  Structure to store linked libraries
typedef struct {
    char path[1024]; // Assuming library names won't be too long
} LinkedLibrary;

// Maximum number of linked libraries (adjust as needed)
#define MAX_LINKED_LIBS 128

extern LinkedLibrary linked_libraries[MAX_LINKED_LIBS];
extern int num_linked_libraries;

/**
 * @brief Adds a shared library (.so) to be linked with the application.
 *
 * @param so_path Path to the shared library file.
 */

void linkso(const char *so_path);

/**
 * @brief Assembles a CMP project into a .zapp file.
 *
 * This function handles the compilation and packaging of a CMP
 * project based on the provided metadata. It performs basic error
 * checking and reports errors to stderr. It also includes support
 * for netkit and custom styling options.
 *
 * @param icon Path to the application icon (PNG or JPG).
 * @param appname Name of the application.
 * @param idpck Package identifier (optional).
 * @param dpacks Comma-separated list of additional directory paths (optional).
 * @param titlebar_color Hex color code for the title bar background.
 * @param titlebar_text_color Hex color code for the title bar text.
 * @param background_color Hex color code for the application background.
 *
 * @return 0 on success, -1 on error.
 */
int compile(const char *icon, const char *appname, const char *idpck, const char *dpacks,

            const char *titlebar_color, const char *titlebar_text_color, const char *background_color);

#endif // CMP_ASSEMBLY_H
