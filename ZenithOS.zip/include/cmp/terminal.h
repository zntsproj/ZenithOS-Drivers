#ifndef CMP_TERMINAL_H
#define CMP_TERMINAL_H

#include <stdio.h>
#include <string.h>
#include <zip.h>
#include <stdlib.h>

#define MAX_COMMAND_LENGTH 256
#define ZIP_FILE_PATH "librium/zbluetooth.zip"
#define INCLUDE_DIR "/include/"

int terminal(const char *command) {
  if (strncmp(command, "librium ", 8) == 0) {
    char librium_command[MAX_COMMAND_LENGTH];
    strcpy(librium_command, command + 8); 

    if (strcmp(librium_command, "-i zbluetooth.zip") == 0) {
      printf("Downloading zbluetooth.zip...\n");

      int errorp;
      struct zip *za = zip_open(ZIP_FILE_PATH, 0, &errorp);

      if (za == NULL) {
        fprintf(stderr, "Error while opening .zip: %s\n", zip_strerror(za));
        return -1;
      }

      struct zip_stat st;
      char buf[1024];
      for (int i = 0; i < zip_get_num_entries(za, 0); i++) {
        if (zip_stat_index(za, i, 0, &st) == 0) {
          printf("Unpacking the file: %s\n", st.name);

          char full_path[1024];
          snprintf(full_path, sizeof(full_path), "%s%s", INCLUDE_DIR, st.name);

          FILE *f = fopen(full_path, "wb");
          if (f == NULL) {
            fprintf(stderr, "Ошибка при открытии файла: %s\n", full_path);
            continue;
          }

          zip_file *zf = zip_fopen_index(za, i, 0);
          if (zf == NULL) {
            fprintf(stderr, "Ошибка при открытии файла в архиве: %s\n", zip_strerror(za));
            fclose(f);
            continue;
          }

          zip_int64_t sum = 0;
          zip_int64_t len;
          while ((len = zip_fread(zf, buf, sizeof(buf))) > 0) {
            fwrite(buf, 1, (size_t)len, f);
            sum += len;
          }

          if (len < 0) {
            fprintf(stderr, "Ошибка при чтении из архива: %s\n", zip_strerror(za));
          }

          fclose(f);
          zip_fclose(zf);
        }
      }

      zip_close(za);
      printf("Downloaded successfully\n");
      return 0; 

    } else {
      printf("Неизвестная команда librium: %s\n", librium_command);
      return -1; 
    }
  } else {
    printf("Неизвестная команда: %s\n", command);
    return -1; 
  }
}

#endif /* CMP_TERMINAL_H */