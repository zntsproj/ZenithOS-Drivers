/**
 * @file cmp/widgets.h
 * @brief Header file for working with widgets in CMP.
 *
 * This file contains type definitions and functions for creating and managing widgets.
 */

#ifndef CMP_WIDGETS_H
#define CMP_WIDGETS_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>

/**
 * @brief Structure for representing a color.
 *
 * Color components (r, g, b) are values from 0 to 255.
 */
typedef struct {
    unsigned char r, g, b;
} Color;

/**
 * @brief Creates and displays a text widget.
 *
 * @param renderer Pointer to the SDL renderer.
 * @param text The text to be displayed in the widget.
 * @param x The X coordinate of the top-left corner of the widget.
 * @param y The Y coordinate of the top-left corner of the widget.
 * @param fg The foreground color (text color).
 * @param bg The background color. Currently not used.
 *
 * @return Returns 0 on success, -1 on error.
 *
 * @note Requires initialized SDL and SDL_ttf.
 *       The font path is hardcoded in the function implementation
 *       and needs to be changed if necessary.
 */

int adwid(SDL_Renderer *renderer, const char *text, int x, int y, Color fg, Color bg);


/**
 * @brief Creates and displays a button widget.
 *
 * @param renderer Pointer to the SDL renderer.
 * @param text The text to be displayed on the button.
 * @param bg The background color of the button.
 * @param fg The foreground color (text color).
 * @param x The X coordinate of the top-left corner of the button.
 * @param y The Y coordinate of the top-left corner of the button.
 *
 * @return 0 on success, -1 on error.
 */
int adwid_button(SDL_Renderer *renderer, const char *text, Color bg, Color fg, int x, int y);

// Creates the image widget
int adwid_image(SDL_Renderer *renderer, const char *image_path, int x, int y);

#endif // CMP_WIDGETS_H