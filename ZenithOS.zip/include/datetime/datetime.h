#ifndef DATETIME_H
#define DATETIME_H

#include <time.h>

/**
* @brief Returns the current time and date as a string.
* 
* @param format A format string, such as "%Y-%m-%d %H:%M:%S".
* @return A string with the current time and date in the given format.
*/

char *datetime_now(const char *format) {
    time_t now = time(NULL);
    struct tm *timeinfo = localtime(&now);
    
    static char buffer[80];
    strftime(buffer, sizeof(buffer), format, timeinfo);
    
    return buffer; 
}

#endif /* DATETIME_H */