// crypto.h
#ifndef CRYPTO_H_
#define CRYPTO_H_

#include <openssl/pem.h>
#include <openssl/x509.h>
#include <openssl/rsa.h>
#include <time.h>

// Function to generate a self-signed certificate
int pemcert(const char *author, const char *location, int key_length, const char *until_date);

#endif  // CRYPTO_H_