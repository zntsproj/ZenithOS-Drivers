#include "nfc.h"
#include <stdio.h>

int main() {
  char data[128];  // Buffer to store read data

  if (!nfc_init()) {
    fprintf(stderr, "Error initializing NFC reader.\n");
    return 1;
  }

  if (nfc_read_tag(data, sizeof(data))) {
    printf("Data read from tag: %s\n", data);  // Ensure data is null-terminated
  } else {
    printf("Error reading NFC tag.\n");
  }

  if (nfc_write_tag("Hello, NFC!", 13)) { // 12 characters + null terminator
      printf("Data written successfully!\n");
  }
  else {
      printf("Error writing NFC data.\n");
  }

  if (!nfc_close()) {
    printf("Error closing NFC reader.\n");

  }

  return 0;

}