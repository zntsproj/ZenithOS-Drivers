// nfc.h
#ifndef NFC_H_
#define NFC_H_

#include <stdbool.h>  // For bool type

/**
 * @brief Initializes the NFC reader.
 * @return True on success, false on error.
 */
bool nfc_init(void);

/**
 * @brief Reads data from an NFC tag.
 * @param data Buffer to store the read data.
 * @param data_size Size of the data buffer.
 * @return True on success, false on error.
 */
bool nfc_read_tag(char *data, size_t data_size);

/**
 * @brief Writes data to an NFC tag.
 * @param data Data to write to the tag.
 * @param data_size Size of the data to write.
 * @return True on success, false on error.
 */
bool nfc_write_tag(const char *data, size_t data_size);

/**
 * @brief Closes the NFC reader.
 * @return True on success, false on error.
 */
bool nfc_close(void);

#endif // NFC_H_