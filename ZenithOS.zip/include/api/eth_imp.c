#include "api/eth.h"
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <net/if.h>  // For ifreq structure
#include <unistd.h>
#include <linux/wireless.h> // For wireless extensions

bool eth_get_rssi(const char *interface_name, int *rssi) {
#ifdef __linux__ // This part is Linux-specific
    int sockfd;
    struct iwreq wreq;

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return false;
    }

    strncpy(wreq.ifr_name, interface_name, IFNAMSIZ - 1); // Use safer string copy function.
    wreq.ifr_name[IFNAMSIZ - 1] = '\0'; // Ensure null termination.

    if (ioctl(sockfd, SIOCGIWESSID, &wreq) == 0) {
        *rssi = (int)wreq.u.essid.length; // RSSI is typically in wreq.u.qual.level
        close(sockfd);
        return true;
    } else {
        perror("ioctl[SIOCGIWESSID]");
        close(sockfd);
        return false;
    }

#else
    // Implement for other OSs if needed
    return false;
#endif

}

bool eth_get_interface_info(const char *interface_name, eth_interface_info_t *info) {
    // Placeholder implementation - Replace with actual logic to retrieve interface information.
    struct ifreq ifr;
    int fd;

    fd = socket(AF_INET, SOCK_DGRAM, 0);
    if (fd < 0) {
        perror("socket");
        return false;
    }
    strncpy(ifr.ifr_name, interface_name, IFNAMSIZ - 1);
    ifr.ifr_name[IFNAMSIZ - 1] = '\0';
    if (ioctl(fd, SIOCGIFFLAGS, &ifr) < 0) {
        perror("SIOCGIFFLAGS");
        close(fd);
        return false;
    }

    strncpy(info->name, interface_name, sizeof(info->name) - 1);
    info->name[sizeof(info->name) - 1] = '\0';

    close(fd);
    return true; // Replace with actual success/failure check

}