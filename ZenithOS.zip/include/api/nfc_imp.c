// nfc_imp.c
#include "nfc.h"
#include <nfc/nfc.h> // libnfc header
#include <stdio.h>
#include <string.h>

nfc_device *pnd; // Global NFC device handle

bool nfc_init(void) {
    nfc_context *context;
    nfc_init(&context);
    if (context == NULL) {
        fprintf(stderr, "Unable to init libnfc (malloc)\n");
        return false;
    }

    pnd = nfc_open(context, NULL);

    if (pnd == NULL) {
        fprintf(stderr, "ERROR: %s\n", "Unable to open NFC device.");
        nfc_exit(context);
        return false;
    }

    if (nfc_initiator_init(pnd) < 0) {
        fprintf(stderr, "ERROR: %s\n", "Unable to init NFC initiator.");
        nfc_close(pnd);
        nfc_exit(context);
        return false;
    }

    printf("NFC reader opened\n");

    return true;

}

bool nfc_read_tag(char *data, size_t data_size) {
    // todo: Implement NFC tag reading logic here using libnfc functions nfc_initiator_select_passive_target, nfc_initiator_transceive_bytes)
    printf("nfc_read_tag called\n"); // Placeholder

    return true;  // Replace with actual success/failure status

}

bool nfc_write_tag(const char *data, size_t data_size) {
    // todo: Implement NFC tag writing logic here using libnfc functions
 nfc_initiator_select_passive_target, nfc_initiator_transceive_bytes)
    printf("nfc_write_tag called\n"); // Placeholder

    return true; // Replace with actual success/failure status
}

bool nfc_close(void) {

    if(pnd != NULL) {
      nfc_close(pnd);

      nfc_context *context;
      nfc_init(&context); // Get context before exit
      nfc_exit(context);

      pnd = NULL;  // Reset handle after closing
      printf("NFC reader closed\n");
      return true;
    }

    return false;
}