#include "api/eth.h"
#include <stdio.h>

int main() {
    int rssi;
    eth_interface_info_t info;

    if (eth_get_rssi("wlan0", &rssi)) {
        printf("RSSI: %d\n", rssi);
    } else {
        printf("Error getting RSSI.\n");
    }

    if (eth_get_interface_info("eth0", &info)) {
        printf("Interface Name: %s\n", info.name);
    } else {
        printf("Error getting interface info.\n");
    }

    return 0;
}