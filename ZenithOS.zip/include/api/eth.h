#ifndef API_ETH_H_
#define API_ETH_H_

#include <stdbool.h>

// Structure to hold interface information
typedef struct {
    char name[16];         // Interface name (e.g., "wlan0")
    char mac_address[18]; // MAC address
    char ip_address[16];  // IP address
    // ... other fields as needed
} eth_interface_info_t;

/**
 * @brief Gets the RSSI (Received Signal Strength Indicator) for a wireless interface.
 *
 * @param interface_name The name of the wireless interface (e.g., "wlan0").
 * @param rssi Output parameter to store the RSSI value.
 * @return True on success, false on error.
 */
bool eth_get_rssi(const char *interface_name, int *rssi);

/**
 * @brief Gets information about a network interface.
 *
 * @param interface_name The name of the network interface.
 * @param info Output parameter to store the interface information.
 * @return True on success, false on error.
 */
bool eth_get_interface_info(const char *interface_name, eth_interface_info_t *info);

#endif // API_ETH_H_