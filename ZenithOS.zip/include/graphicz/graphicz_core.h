#ifndef _ZENITH_GRAPHICS_H
#define _ZENITH_GRAPHICS_H

#include <SDL2/SDL.h>
#include <stdint.h>

typedef struct color {
    uint8_t r;
    uint8_t g;
    uint8_t b;
} color_t;

static SDL_Renderer *renderer = NULL; // make it static
static SDL_Window *window = NULL;     // and this one too

int init_graphics(void) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        return -1;
    }

    window = SDL_CreateWindow("ZenithOS App", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, 800, 600, SDL_WINDOW_SHOWN);
    if (window == NULL) {
        SDL_Quit();
        return -1;
    }

    renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED);
    if (renderer == NULL) {
        SDL_DestroyWindow(window);
        SDL_Quit();
        return -1;
    }
    return 0;
}

SDL_Renderer* get_renderer(void) {
    return renderer;
}

void set_color(SDL_Renderer *renderer, color_t color) {
    SDL_SetRenderDrawColor(renderer, color.r, color.g, color.b, 255);
}

void clear_screen(SDL_Renderer *renderer, color_t color) {
    set_color(renderer, color);
    SDL_RenderClear(renderer);
}

int draw_line(SDL_Renderer *renderer, int x1, int y1, int x2, int y2, color_t color) {
    set_color(renderer, color);
    if(SDL_RenderDrawLine(renderer, x1, y1, x2, y2) < 0){
        return -1;
    }
    SDL_RenderPresent(renderer);
    return 0;
}

#endif // _ZENITH_GRAPHICS_H