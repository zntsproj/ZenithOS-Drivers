#include "cmp/assembly.h"
#include <stdio.h>

int main() {
    const char *icon_path = "path/to/your/icon.png"; // Replace with the actual path to your icon
    const char *app_name = "MyCoolApp";
    const char *package_id = "com.example.myapp";  //  Optional package ID
    const char *directories_to_add = "src,res,assets"; // Comma-separated list of directories
    const char *titlebar_color = "#0078D7";       // Example: Blue titlebar
    const char *titlebar_text_color = "#FFFFFF";   // Example: White text
    const char *background_color = "#F0F0F0";     // Example: Light gray background

    if (compile(icon_path, app_name, package_id, directories_to_add,
                titlebar_color, titlebar_text_color, background_color) != 0) {

        fprintf(stderr, "Compilation failed.\n");
        return 1;
    } else {
        printf("Compilation successful!\n");
    }

    return 0;
}