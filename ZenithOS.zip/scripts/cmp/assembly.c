// cmp/assembly.c
#include "cmp/assembly.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zip.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>

LinkedLibrary linked_libraries[MAX_LINKED_LIBS];
int num_linked_libraries = 0;

typedef struct {
    char titlebar_color[16];
    char titlebar_text_color[16];
    char background_color[16];
} StyleInfo;

int add_to_zip(zip_t *zip_archive, const char *filepath, const char *zip_path) {
    struct stat st;
    if (stat(filepath, &st) != 0) {
        fprintf(stderr, "Error accessing '%s': %s\n", filepath, strerror(errno));
        return -1;

    }

    if (S_ISREG(st.st_mode)) {
        zip_source_t *source = zip_source_file(zip_archive, filepath, 0, 0);

        if (!source) {

            fprintf(stderr, "Error adding file '%s': %s\n", filepath, zip_strerror(zip_archive));
            return -1;
        }

        if (zip_file_add(zip_archive, zip_path, source, ZIP_FL_OVERWRITE) < 0) {

            fprintf(stderr, "Error adding file '%s' to zip: %s\n", filepath, zip_strerror(zip_archive));
            zip_source_free(source);
            return -1;

        }

        return 0;
    } else if (S_ISDIR(st.st_mode)) {
        DIR *dir = opendir(filepath);

        if (!dir) {

            fprintf(stderr, "Error opening directory '%s': %s\n", filepath, strerror(errno));

            return -1;
        }

        struct dirent *entry;
        while ((entry = readdir(dir)) != NULL) {

            if (strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0) {
                continue;
            }

            char full_path[512];
            char zip_full_path[512];

            snprintf(full_path, sizeof(full_path), "%s/%s", filepath, entry->d_name);
            snprintf(zip_full_path, sizeof(zip_full_path), "%s/%s", zip_path, entry->d_name);

            if (add_to_zip(zip_archive, full_path, zip_full_path) < 0) {
                closedir(dir);

                return -1;
            }
        }

        closedir(dir);
        return 0;
    } else {

        return -1;
    }

}

// Function to create the "lib" directory inside the zapp archive
int create_lib_directory(zip_t* zip_archive) {
    zip_source_t* source = zip_source_buffer(zip_archive, "", 0, 0); // Empty buffer
    int index = zip_file_add(zip_archive, "lib/", source, ZIP_FL_OVERWRITE | ZIP_FL_ENC_UTF_8);

    if (index < 0) {
        fprintf(stderr, "Error adding lib directory: %s\n", zip_strerror(zip_archive));
        return -1;

    }

    return 0;

}

void linkso(const char *so_path) {

    if (num_linked_libraries < MAX_LINKED_LIBS) {
        strncpy(linked_libraries[num_linked_libraries].path, so_path, sizeof(linked_libraries[0].path) - 1);
        num_linked_libraries++;
    } else {
        fprintf(stderr, "Error: Too many linked libraries. Increase MAX_LINKED_LIBS.\n");
    }

}

char* create_style_content(StyleInfo *style) {

    char *buffer = (char *)malloc(512);
    if (!buffer) {
        perror("malloc failed for style content");
        return NULL;

    }

    snprintf(buffer, 512,

             ":root {\n"
             "  --titlebar-color: %s;\n"

             "  --titlebar-text-color: %s;\n"

             "  --background-color: %s;\n"
             "}\n",
             style->titlebar_color, style->titlebar_text_color, style->background_color);
    return buffer;

}
int compile(const char *icon, const char *appname, const char *idpck, const char *dpacks,
            const char *titlebar_color, const char *titlebar_text_color, const char *background_color) {
    if (!icon || !appname) {
        fprintf(stderr, "Error: Missing required arguments (icon and appname).\n");
        return -1;
    }

    StyleInfo style = {0};
    strncpy(style.titlebar_color, titlebar_color, sizeof(style.titlebar_color) - 1);

    strncpy(style.titlebar_text_color, titlebar_text_color, sizeof(style.titlebar_text_color) - 1);
    strncpy(style.background_color, background_color, sizeof(style.background_color) - 1);

    char zapp_filename[256];

    snprintf(zapp_filename, sizeof(zapp_filename), "%s.zapp", appname);

    int errorp;
    zip_t *zip_archive = zip_open(zapp_filename, ZIP_CREATE | ZIP_TRUNCATE, &errorp);

    if (!zip_archive) {

        zip_error_t ziperror;
        zip_error_init(&ziperror);
        zip_error_set(&ziperror, errorp, 0);

        fprintf(stderr, "Error creating zip archive '%s': %s\n", zapp_filename, zip_error_strerror(&ziperror));
        zip_error_fini(&ziperror);

        return -1;

    }

    if (add_to_zip(zip_archive, icon, "icon.png") < 0) {
        zip_close(zip_archive);

        return -1;

    }

    // Create lib directory in zip

    create_lib_directory(zip_archive);

    // Add linked libraries to "lib" directory inside the zip
    for (int i = 0; i < num_linked_libraries; i++) {

        char zip_lib_path[1024];
        snprintf(zip_lib_path, sizeof(zip_lib_path), "lib/%s", strrchr(linked_libraries[i].path, '/') + 1);  // Extract filename from path

        if (add_to_zip(zip_archive, linked_libraries[i].path, zip_lib_path) < 0) {

            zip_close(zip_archive);
            return -1;

        }

    }

    char config_content[256];

    snprintf(config_content, sizeof(config_content), "appname=%s\nidpck=%s\n", appname, idpck ? idpck : "");

    zip_source_t *config_source = zip_source_buffer(zip_archive, config_content, strlen(config_content), 0);

    if (!config_source || zip_file_add(zip_archive, "config.txt", config_source, ZIP_FL_OVERWRITE) < 0) {
        fprintf(stderr, "Error adding config file: %s\n", zip_strerror(zip_archive));

        zip_source_free(config_source);
        zip_close(zip_archive);

        return -1;

    }

    char *style_content = create_style_content(&style);

    if (!style_content) {
        zip_close(zip_archive);

        return -1;

    }

    zip_source_t *style_source = zip_source_buffer(zip_archive, style_content, strlen(style_content), 0);

    if (!style_source || zip_file_add(zip_archive, "style.css", style_source, ZIP_FL_OVERWRITE) < 0) {

        fprintf(stderr, "Error adding style.css: %s\n", zip_strerror(zip_archive));
        zip_source_free(style_source);

        free(style_content);

        zip_close(zip_archive);

        return -1;

    }

    free(style_content);

    if (dpacks) {
        char *dpacks_copy = strdup(dpacks);

        if (!dpacks_copy) {

            perror("strdup failed");
            zip_close(zip_archive);

            return -1;

        }

        char *token = strtok(dpacks_copy, ",");

        while (token != NULL) {
            if (add_to_zip(zip_archive, token, token) < 0) {
                free(dpacks_copy);
                zip_close(zip_archive);
                return -1;

            }

            token = strtok(NULL, ",");

        }

        free(dpacks_copy);

    }

    zip_close(zip_archive);
    printf(".zapp archive '%s' created successfully!\n", zapp_filename);

    return 0;

}