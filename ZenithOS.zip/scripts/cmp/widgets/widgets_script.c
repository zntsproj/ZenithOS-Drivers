#include "cmp/widgets.h"
#include <SDL2/SDL_ttf.h>
#include <SDL2/SDL_image.h>
#include <stdio.h>
#include <string.h>
#include <stdbool.h>

Color hex_to_color(const char *hex_color) {
    Color color = {0, 0, 0};
    if (hex_color && strlen(hex_color) == 7 && hex_color[0] == '#') {
        unsigned int rgb_value = strtol(hex_color + 1, NULL, 16);
        color.r = (rgb_value >> 16) & 0xFF;
        color.g = (rgb_value >> 8) & 0xFF;
        color.b = rgb_value & 0xFF;
    } else {
        fprintf(stderr, "Warning: invalid hex color format '%s'. Using black.\n", hex_color ? hex_color : "NULL");
    }
    return color;
}

int adwid(SDL_Renderer *renderer, const char *text, int x, int y, Color fg, Color bg) {
    TTF_Font* font = TTF_OpenFont("path/to/your/font.ttf", 12);
    if (!font) {
        fprintf(stderr, "Error loading font: %s\n", TTF_GetError());
        return -1;
    }

    SDL_Surface* text_surface = TTF_RenderText_Solid(font, text, fg);
    if (!text_surface) {
        fprintf(stderr, "Error rendering text: %s\n", TTF_GetError());
        TTF_CloseFont(font);
        return -1;
    }

    SDL_Texture* text_texture = SDL_CreateTextureFromSurface(renderer, text_surface);
    SDL_FreeSurface(text_surface);
    TTF_CloseFont(font);

    if (!text_texture) {
        fprintf(stderr, "Error creating text texture: %s\n", SDL_GetError());
        return -1;
    }

    SDL_Rect text_rect;
    TTF_SizeText(font, text, &text_rect.w, &text_rect.h);
    text_rect.x = x;
    text_rect.y = y;

    SDL_RenderCopy(renderer, text_texture, NULL, &text_rect);
    SDL_DestroyTexture(text_texture);

    return 0;
}

bool adwid_button(SDL_Renderer *renderer, const char *text, const char *bg_hex, const char* fg_hex, int x, int y, bool *button_pressed, int screen_w, int screen_h) {
    Color bg = hex_to_color(bg_hex);
    Color fg = hex_to_color(fg_hex);

    SDL_Rect rect = {x, y, 100, 30};

    SDL_SetRenderDrawColor(renderer, bg.r, bg.g, bg.b, 255);
    SDL_RenderFillRect(renderer, &rect);

    int text_width, text_height;
    TTF_Font* font = TTF_OpenFont("path/to/your/font.ttf", 12);
    if (!font) {
        fprintf(stderr, "Error loading font: %s\n", TTF_GetError());
        return false;
    }
    TTF_SizeText(font, text, &text_width, &text_height);
    int text_x = x + (rect.w - text_width) / 2;
    int text_y = y + (rect.h - text_height) / 2;
    adwid(renderer, text, text_x, text_y, fg, bg);
    TTF_CloseFont(font);

    SDL_Event event;
    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_FINGERDOWN || event.type == SDL_MOUSEBUTTONDOWN) {
            int mouse_x, mouse_y;
            if(event.type == SDL_MOUSEBUTTONDOWN){
                mouse_x = event.button.x;
                mouse_y = event.button.y;
            } else {
                mouse_x = event.tfinger.x * screen_w;
                mouse_y = event.tfinger.y * screen_h;
            }

            if (mouse_x > x && mouse_x < x + rect.w && mouse_y > y && mouse_y < y + rect.h) {
                *button_pressed = true;
                SDL_SetRenderDrawColor(renderer, bg.r * 0.8, bg.g * 0.8, bg.b * 0.8, 255);
                SDL_RenderFillRect(renderer, &rect);
                adwid(renderer, text, text_x, text_y, fg, bg);
                SDL_RenderPresent(renderer);
                return true;
            }

        } else if (event.type == SDL_FINGERUP || event.type == SDL_MOUSEBUTTONUP ) {
            int mouse_x, mouse_y;
            if(event.type == SDL_MOUSEBUTTONUP){
                mouse_x = event.button.x;
                mouse_y = event.button.y;
            } else {
                mouse_x = event.tfinger.x * screen_w;
                mouse_y = event.tfinger.y * screen_h;
            }
            if (*button_pressed) {
                *button_pressed = false;
                if (mouse_x > x && mouse_x < x + rect.w && mouse_y > y && mouse_y < y + rect.h) {
                    return true;
                }
            }
        }
    }

    return false;
}

int adwid_image(SDL_Renderer *renderer, const char *image_path, int x, int y) {
    SDL_Surface* image_surface = IMG_Load(image_path);
    if (!image_surface) {
        fprintf(stderr, "Error loading image: %s\n", IMG_GetError());
        return -1;
    }

    SDL_Texture* image_texture = SDL_CreateTextureFromSurface(renderer, image_surface);
    SDL_FreeSurface(image_surface);

    if (!image_texture) {
        fprintf(stderr, "Error creating texture: %s\n", SDL_GetError());
        return -1;
    }

    int image_width = image_surface->w;
    int image_height = image_surface->h;

    SDL_Rect dest_rect = {x, y, image_width, image_height};
    if (SDL_RenderCopy(renderer, image_texture, NULL, &dest_rect) != 0) {
        fprintf(stderr, "Error rendering image: %s\n", SDL_GetError());
        SDL_DestroyTexture(image_texture);
        return -1;
    }

    SDL_DestroyTexture(image_texture);
    return 0;
}