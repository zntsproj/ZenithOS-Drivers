#ifndef INCLUDE_ROOT_H_
#define INCLUDE_ROOT_H_

/**
 * @brief Requests root privileges.
 *
 * This function attempts to escalate privileges to root using a suitable method
 * for the target system.  The implementation details may vary depending on the OS.
 *
 * @return 0 on success, -1 on failure.
 */
int request_root_privileges(void);

#endif  // INCLUDE_ROOT_H_