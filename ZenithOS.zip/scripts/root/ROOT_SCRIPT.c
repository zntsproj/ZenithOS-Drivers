// WARNING: GRANTING ROOT ACCESS IS A VERY DANGEROUS OPERATION.

#include "root.h"
#include <unistd.h>
#include <stdio.h>
#include <errno.h>

int request_root_privileges(void) {

#ifdef __linux__
    if (setuid(0) == -1) {
        perror("setuid");
        return -1;
    }
#else // For different systems maybe use pledge/unveil
    return -1; // Indicate that current system is unsupported
#endif

    if (getuid() != 0) {
        fprintf(stderr, "Failed to obtain root privileges.\n");
        return -1;
    }

   return 0;
}