#include "filesystem.h"
#include <stdio.h>

int main() {
    if (fs_add("/tmp/testfile.txt")) {
        printf("File/Directory created successfully!\n");
    }
    if (fs_rename("/tmp/testfile.txt", "/tmp/newfile.txt")) {
        printf("Renamed successfully!\n");
    }
    if (fs_delete("/tmp/newfile.txt")) {
        printf("Deleted successfully!\n");
    }

    return 0;
}