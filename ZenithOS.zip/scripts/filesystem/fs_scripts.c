#include "filesystem.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>  // Required for mkdir on some systems
#include <errno.h>  // For error handling
#include <string.h>  // For error string

bool fs_delete(const char *path) {
    if (remove(path) == 0) {
        return true;
    } else {
        fprintf(stderr, "Error deleting %s: %s\n", path, strerror(errno));
        return false;
    }
}

bool fs_add(const char *path) {
    struct stat st;

    if (stat(path, &st) == 0) {  // Check if path already exists
        fprintf(stderr, "Error: %s already exists.\n", path);
        return false;  // Indicate failure if path exists
    }

    if (mkdir(path, 0777) == 0) { // Try to create directory if path doesn't exist
        return true;
    }
    else if (errno == ENOTDIR) { // Try to create file if path isn't a directory
      FILE *f = fopen(path, "w+"); // Create an empty file if its parent exists
      if (f) {
        fclose(f);
        return true;
      }
      else {
        fprintf(stderr, "Error creating %s: %s\n", path, strerror(errno));
      }
    }
    else {
      fprintf(stderr, "Error creating %s: %s\n", path, strerror(errno));
      return false; // Couldn't create a directory or file
    }
    return false;
}

bool fs_rename(const char *old_path, const char *new_path) {
    if (rename(old_path, new_path) == 0) {
        return true;
    } else {
        fprintf(stderr, "Error renaming %s to %s: %s\n", old_path, new_path, strerror(errno));
        return false;
    }
}