#include "http.h"
#include <stdlib.h>

size_t write_callback(char* ptr, size_t size, size_t nmemb, void* userdata) {
    struct http_response* response = (struct http_response*)userdata;
    size_t realsize = size * nmemb;

    response->data = realloc(response->data, response->size + realsize + 1); 
    if (response->data == NULL) {
        fprintf(stderr, "realloc() failed\n");
        return 0;
    }

    memcpy(&(response->data[response->size]), ptr, realsize);
    response->size += realsize;
    response->data[response->size] = 0; // Нуль-терминатор

    return realsize;
}

CURLcode http_request(const char* url, const char* method, const char* data, struct http_response* response) {
    CURL* curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "ZenithOS HTTP");

        if (strcmp(method, "POST") == 0) {
            curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
        } 

        response->data = malloc(1); // Инициализация
        response->size = 0;

        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_callback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, response);

        CURLcode res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        return res;
    }
    return CURLE_FAILED_INIT;
}

CURLcode http_get(const char* url, struct http_response* response) {
    return http_request(url, "GET", NULL, response);
}

CURLcode http_post(const char* url, const char* data, struct http_response* response) {
    return http_request(url, "POST", data, response);
}