#include "net/netkit.h"
#include <stdio.h>
#include <string.h>

/**
 * @brief Example of using netkit.h to retrieve routing information.
 *
 * This example demonstrates how to create a netlink socket,
 * send a request to get the routing table, and receive the response.
 *
 * @return 0 on success, 1 on error.
 */
int main() {
    netkit_socket_t sock;  // Netlink socket structure
    char buf[256];      // Buffer for received data

    // Create a netlink socket for routing information (NETLINK_ROUTE).
    if (nl_socket(&sock, NETLINK_ROUTE) < 0) {
        perror("nl_socket");  // Print error message if socket creation fails
        return 1;
    }

    // Prepare a message to request the routing table.
    // rtgenmsg is used for generic routing messages.
    struct rtgenmsg req = { .rtgen_family = AF_INET }; // Request for IPv4 routes

    // Send the request to kernel (port 0 indicates kernel).
    // RTM_GETROUTE is the message type for retrieving routes.
    if (nl_send(&sock, 0, RTM_GETROUTE, &req, sizeof(req)) < 0) {
        perror("nl_send");  // Print error if sending fails
        nl_close(&sock); // Close if we have errors
        return 1;
    }

    // Receive the response from the kernel.
    int len = nl_receive(&sock);
    if (len < 0) {
        perror("nl_receive");  // Print error if receiving fails
        nl_close(&sock); // Close if we have errors
        return 1;
    }

    // Process the received data (example: print the message payload).
    // Iterate through all received netlink messages in the buffer
    struct nlmsghdr *nlh = (struct nlmsghdr *)sock.buf;
    for (; NLMSG_OK(nlh, len); nlh = NLMSG_NEXT(nlh, len)) {
        printf("Received message payload: %s\n", (char *)NLMSG_DATA(nlh));
    }

    nl_close(&sock);  // Close the netlink socket
    return 0;
}