#include "net/scan.h"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ifaddrs.h>

int net_scan(DeviceInfo **devices, int *num_devices)
{

    struct ifaddrs *ifaddr, *ifa;

    if (getifaddrs(&ifaddr) == -1) {

        perror("getifaddrs");
        return 1;

    }

    *num_devices = 0;
    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
    {
        if (ifa->ifa_addr == NULL || ifa->ifa_addr->sa_family != AF_INET)

        {
            continue;

        }

        void *addr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;

        char ip_str[INET_ADDRSTRLEN];
        inet_ntop(AF_INET, addr, ip_str, INET_ADDRSTRLEN);

        // printf("%s: %s\n", ifa->ifa_name, ip_str); // Log or use this information as needed

        (*num_devices)++;

    }

    *devices = (DeviceInfo*)malloc(sizeof(DeviceInfo) * (*num_devices));

    int count = 0;
    for (ifa = ifaddr; ifa != NULL; ifa = ifa->ifa_next)
    {

        if (ifa->ifa_addr == NULL || ifa->ifa_addr->sa_family != AF_INET)

        {
            continue;

        }

        void *addr = &((struct sockaddr_in *)ifa->ifa_addr)->sin_addr;

        inet_ntop(AF_INET, addr, (*devices)[count].ip_address, INET_ADDRSTRLEN);

        //Resolve hostname
          char host[NI_MAXHOST];

            struct sockaddr_in sa;
            sa.sin_family = AF_INET;

            inet_pton(AF_INET, (*devices)[count].ip_address, &sa.sin_addr);

            int res = getnameinfo((struct sockaddr *)&sa, sizeof(sa),

                        host, NI_MAXHOST, NULL, 0, 0);
            if (res == 0) {

              strcpy((*devices)[count].hostname, host);

            } else {
              strcpy((*devices)[count].hostname, "Unknown");
            }

          count++;

    }

    freeifaddrs(ifaddr);

    return 0;

}

int main()
{

  DeviceInfo* devices;
  int num_devices;

  if (net_scan(&devices, &num_devices) == 0) {

        for (int i = 0; i < num_devices; i++) {

            printf("IP: %s, Hostname: %s\n", devices[i].ip_address, devices[i].hostname);

        }

      free(devices);

    }

  return 0;

}