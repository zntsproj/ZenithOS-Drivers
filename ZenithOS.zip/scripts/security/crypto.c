// crypto.c
// script for crypto.c with example down 
#include "crypto.h"

int pemcert(const char *author, const char *location, int key_length, const char *until_date) {

    // Generate RSA key pair
    RSA *rsa_key = RSA_new();
    BIGNUM *bne = BN_new();
    int result = RSA_generate_key_ex(rsa_key, key_length, bne, NULL);
    BN_free(bne);
    if (!result) {
        fprintf(stderr, "RSA key generation failed.\n");
        return 1;
    }

    // Create X509 certificate structure
    X509 *x509 = X509_new();

    // Set serial number (using current time as a simple example)
    ASN1_INTEGER_set(X509_get_serialNumber(x509), (long)time(NULL));

    // Set subject name (author)
    X509_NAME *name = X509_get_subject_name(x509);
    X509_NAME_add_entry_by_txt(name, "CN", MBSTRING_ASC, (unsigned char*)author, -1, -1, 0);
    X509_NAME_add_entry_by_txt(name, "L", MBSTRING_ASC, (const unsigned char *)location, -1, -1, 0);

    // Set issuer name (same as subject for self-signed certificate)
    X509_set_issuer_name(x509, name);

    // Set validity period (until date)
    time_t current_time = time(NULL);
    X509_gmtime_adj(X509_get_notBefore(x509), 0); // Not before: now

    struct tm tm;
    strptime(until_date, "%m/%d/%Y", &tm);
    time_t until_time = mktime(&tm);
    X509_gmtime_adj(X509_get_notAfter(x509), until_time - current_time); // Not after: until date

    // Set public key
    X509_set_pubkey(x509, rsa_key);

    // Sign the certificate (self-signed)
    if (!X509_sign(x509, rsa_key, EVP_sha256())) {

        fprintf(stderr, "Certificate signing failed.\n");
        RSA_free(rsa_key);
        X509_free(x509);
        return 1;
    }

    // Write certificate to PEM file
    FILE *pem_file = fopen("certificate.pem", "w");
    if (!pem_file) {
        fprintf(stderr, "Error opening PEM file for writing.\n");
        RSA_free(rsa_key);
        X509_free(x509);
        return 1;
    }
    PEM_write_X509(pem_file, x509);
    fclose(pem_file);

    RSA_free(rsa_key);
    X509_free(x509);

    printf("Certificate generated successfully.\n");

    return 0;

}


// !!EXAMPLE!! ↓↓↓↓↓


int main() {
    pemcert("ZenithOS Team", "Russia", 2048, "01/25/2025");
    return 0;
}