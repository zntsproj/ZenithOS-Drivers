# ZenithOS SDK Documentation

This document provides an overview of the ZenithOS SDK and its features.

## File System, NFC, ETHTOOL, and PEM Certificates

The SDK provides functionalities for interacting with the file system, NFC, and ETHTOOL. It also includes functions for creating PEM certificates. Specific details and examples will be provided in future updates.

## Shared Libraries (.so)

ZenithOS now supports dynamic linking with shared libraries (.so files). To link your application with a shared library, use the `linkso()` function before calling `compile()`:

linkso("path/to/lib.so");

Make sure the shared library is accessible at runtime. Shared libraries are packaged into the .zapp archive within the lib/ directory.

Widgets

The SDK offers a set of widgets to create user interfaces:

Text Widget

int adwid(SDL_Renderer *renderer, const char *text, int x, int y, Color fg, Color bg);

• renderer: Pointer to the SDL renderer.
• text: The text to display.
• x, y: Coordinates of the top-left corner.
• fg: Foreground color (text color).
• bg: Background color (currently not used).

Button Widget

int adwid_button(SDL_Renderer *renderer, const char *text, const char *bg_hex, const char* fg_hex, int x, int y);

• renderer: Pointer to the SDL renderer.
• text: Text to display on the button.
• bg_hex: Background color (hex code, e.g., "#RRGGBB").
• fg_hex: Foreground color (text color, hex code).
• x, y: Coordinates of the top-left corner.

Image Widget

int adwid_image(SDL_Renderer *renderer, const char *image_path, int x, int y);

• renderer: Pointer to the SDL renderer.
• image_path: Path to the image file (PNG or JPG).
• x, y: Coordinates of the top-left corner.

Icons

ZenithOS supports icons in two resolutions: 56x56 and 128x128. Provide icons in PNG or JPG format. When packaging your application, include the desired icon file named "icon.png".

Building Applications

Use the compile() function (in cmp/assembly.h, scripts/cmp/assembly.c) to build your application:

int compile(const char *icon, const char *appname, const char *idpck, const char *dpacks,
            const char *titlebar_color, const char *titlebar_text_color, const char *background_color);

• icon: Path to the application icon.
• appname: Application name.
• idpck: Package identifier (optional).
• dpacks: Additional directories to include (comma-separated, optional).
• titlebar_color: Title bar background color (hex code).
• titlebar_text_color: Title bar text color (hex code).
• background_color: Application background color (hex code).

Future Updates

More detailed documentation and examples will be provided in future SDK updates. Stay tuned!